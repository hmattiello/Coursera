
public interface Embaralhador {
	public void EmbaralharPalavra (String palavra);
	public String getPalavraEmbaralhada ();
}
